$("#newpastenavbutton").click(function () {
    location.reload();
});