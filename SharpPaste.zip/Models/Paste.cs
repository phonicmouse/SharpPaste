﻿/*
 * Created by SharpDevelop.
 * User: Phonic Mouse
 * Date: 01/08/2016
 * Time: 20:09
 */
using System;

namespace SharpPaste
{
	public class Paste
	{
		public int Id { get; set; }
		public string LongId { get; set; }
		public string Title { get; set; }
		public string Body { get; set; }
		public bool Highlighting { get; set; }
	}
}
